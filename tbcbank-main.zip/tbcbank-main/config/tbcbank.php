<?php

// config for Giorgigigauri/Tbcbank
return [
    'client_id' => env('TBC_CLIENT_ID', ''),
    'client_secret' => env('TBC_CLIENT_SECRET', ''),
    'api_key' => env('TBC_API_KEY', ''),
    'api_url' => env('TBC_API_URL', ''),
    'callback_url' => env('TBC_CALLBACK_URL', ''),
];
