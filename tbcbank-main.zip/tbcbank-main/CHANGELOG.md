# Changelog

All notable changes to `tbcbank` will be documented in this file.

## Release: v0.0.2 - 2023-06-30

### What's Changed

- Bump dependabot/fetch-metadata from 1.4.0 to 1.5.1 by @dependabot in https://github.com/giorgigigauri/tbcbank/pull/10

**Full Changelog**: https://github.com/giorgigigauri/tbcbank/compare/v0.0.1...v0.0.2

## Release: v0.0.1 - 2023-05-06

Initial release

Note: project is in very early development phase.

**Full Changelog**: https://github.com/giorgigigauri/tbcbank/commits/v0.0.1
